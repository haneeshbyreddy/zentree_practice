// log_config.h
#ifndef LOG_CONFIG_H
#define LOG_CONFIG_H

// Set the log level here
#define CURRENT_LOG_LEVEL LOG_LEVEL_DEBUG

#endif // LOG_CONFIG_H

